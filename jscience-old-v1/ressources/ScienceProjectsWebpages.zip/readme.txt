http://www.madscitech.org/projects.html

Reprinted WITHOUT permission.