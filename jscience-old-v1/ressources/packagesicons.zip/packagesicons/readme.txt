These icons were found on:
http://www.iconarchive.com/
http://www.icon-king.com/
http://www.iconutils.com/
http://www.coolarchive.com/

(apart a couple of them that I designed) and are basically free for non commercial use (the ones from iconking are available under GPL).

All icons are 48x48 in png. They are also probably all with RGB color and no transparency (although I haven't checked them all).

The complete Licence icon by icon is as follows:
architecture, iconking, GPL 
astronomy, ?????????????????
awt, iconking, GPL
bibliography, iconking, GPL
biology, iconking, GPL
chemistry, iconking, GPL
computing, iconking, GPL
devices, iconking, GPL
disabilities, iconking, GPL
earth, iconking, GPL
economics, ?????????????????
engineering, iconking, GPL
geography, myself, GPL
help, iconking, GPL
history, iconking, GPL
io, myself, probably free (based on an icon from WindowsXP set)
jscience, myself, license unknown, based on a logo from Sun Microsystem: "the Duke logo and the Java Coffee Cup logo are trademarks or registered trademarks of Sun Microsystems, Inc. in the U.S. and other countries", see http://www.sun.com/policies/trademarks
law, free (http://www.iconutils.com/iconlibs.htm)
linguistics, iconking, GPL
mathematics, iconking, GPL
measure, iconking, GPL
media, iconking, GPL
medicine, myself, GPL
ml, ?????????????????
net, iconking, GPL
package, iconking, GPL
philosophy, myself, GPL
physics, iconking, GPL
politics, iconking, GPL
psychology, myself, GPL
sociology, iconking, GPL
swing, iconking, GPL
teaching, iconking, GPL
tests, free (http://www.icongalore.com/download/xp-icons.zip)
text, iconking, GPL
util, myself, license unknown, based on a logo from Sun Microsystem: "the Duke logo and the Java Coffee Cup logo are trademarks or registered trademarks of Sun Microsystems, Inc. in the U.S. and other countries", see http://www.sun.com/policies/trademarks


Licence for alternate icons:
astronomy, myself, GPL
engineering, free for non commercial (based on an Image from www.ignorancia.org)
geography1, iconarchive, licence unknown
geography2, myself, GPL
history, iconking, GPL
medicine1, ?????????????????
medicine2, iconarchive, licence unknown
philosophy1, myself, GPL
philosophy2, iconking, GPL
psychology, iconarchive, licence unknown
util, myself, GPL (based on an icon from iconking)
